import torch
from torchvision import transforms
import cv2

def video_transforms(video_path ,img_size,n_frame=50):

    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    resize = transforms.Resize(img_size)  # Resize to (470, 800)
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("Error opening video file")

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    frames = []
    if total_frames < n_frame:
        while True:
            ret, frame = cap.read()  
            if not ret:
                break  

            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame_pil = transforms.ToPILImage()(frame)
            frame_resized = resize(frame_pil)
            frame_tensor = transforms.ToTensor()(frame_resized)
            frame_normalized = normalize(frame_tensor)
            frames.append(frame_normalized)

        # If the number of frames is less than n_frame, repeat the frame.
        frames *= (n_frame // len(frames)) + 1  # Calculate how many times it needs to be repeated.
        # print(len(frames))
        frames = frames[:n_frame]  
    else:
        frame_indices = torch.linspace(0, total_frames - 1, n_frame).long()  
        for index in frame_indices:
            index =int(index)
            cap.set(cv2.CAP_PROP_POS_FRAMES, index) 
            ret, frame = cap.read() 

            if not ret:
                print(f"Error reading frame at index {index}")
                continue  

            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame_pil = transforms.ToPILImage()(frame)
            frame_resized = resize(frame_pil)
            frame_tensor = transforms.ToTensor()(frame_resized)
            frame_normalized = normalize(frame_tensor)
            frames.append(frame_normalized)

    cap.release()
    video_tensor = torch.stack(frames)
    return video_tensor