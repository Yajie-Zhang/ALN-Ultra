python main.py --device cuda:7 --root yourpath --batch_size 8 --n_frame 50 --epoch 100
