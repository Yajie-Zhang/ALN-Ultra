import torch
import json
import random
import numpy as np
from sklearn.model_selection import StratifiedKFold
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image
import imageio
import cv2

def select_metastasis(data_list,label_list):
    data_selected=[]
    label_selected=[]
    for i in range(len(data_list)):
        cur_data=data_list[i]
        cur_label=label_list[i]
        if cur_label!=2:
            data_selected.append(cur_data)
            label_selected.append(cur_label)
    return data_selected,label_selected

def data_split(json_file,select=False,random_seed=0):
    np.random.seed(random_seed)
    random.seed(random_seed)
    with open(json_file, 'r', encoding='utf-8') as file:  
        data_json = json.load(file)
    data_list=[]
    label_list=[]
    for key in data_json:
        data_list.append(data_json[key])
        cur_label=(data_json[key][0]).split(' ')[1]
        label_list.append(int(cur_label))
    if select==True:
        data_list,label_list=select_metastasis(data_list,label_list)
    kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_seed)
    label_numpy=np.array(label_list)

    train_index_collection=[]
    test_index_collection=[]
    for train_index, test_index in kf.split(label_numpy,label_numpy):
        train_index_collection.append(train_index)
        test_index_collection.append(test_index)
    return data_list,train_index_collection,test_index_collection


def augment_frame(frame):
    angle = np.random.uniform(-30, 30)
    h, w = frame.shape[1:3]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    frame = cv2.warpAffine(frame.transpose(1, 2, 0), M, (w, h))  

    x = np.random.randint(0, w - 100)
    y = np.random.randint(0, h - 100)
    frame = frame[y:y + 100, x:x + 100, :]

    if np.random.rand() > 0.5:
        frame = np.flip(frame, axis=1)  

    return frame.transpose(2, 0, 1) 

def augment_video(video_tensor):
    video_tensor=torch.tensor(video_tensor)
    transform = transforms.Compose([
        transforms.ToPILImage(),  
        transforms.RandomRotation(30), 
        # transforms.RandomCrop((120,180)),  
        # transforms.RandomHorizontalFlip(),  
        transforms.Resize((128, 200)),  
        transforms.ToTensor(),  
    ])


    augmented_frames = []
    for i in range(video_tensor.size(0)): 
        frame = video_tensor[i, :, :, :]  
        augmented_frame = transform(frame)  
        augmented_frames.append(augmented_frame)

    augmented_video_tensor = torch.stack(augmented_frames, dim=0)  
    return augmented_video_tensor

class Dataset_Video_Image(Dataset):
    def __init__(self, root, data_list,video_list, img_size=(470, 800),n_frame=100,is_train=True):
        self.root = root
        self.data = data_list
        self.img_size = img_size
        self.n_frame=n_frame
        self.is_train=is_train
        # self.video_list=self.video_extract()
        self.video_list=video_list


    def video_extract(self):
        video_list=[]
        for data in self.data:
            video_path = data[1][0].split('_')[0]
            video_path = self.root + '/video_concate/' + video_path + '.avi'
            video_value = self.video_transforms(video_path, n_frame=self.n_frame)
            video_list.append(video_value)
        return video_list

    def train_transforms(self, img):
        img = transforms.Resize((int(1.05 * self.img_size[0]), int(1.05 * self.img_size[1])), Image.BILINEAR)(img)
        img = transforms.RandomHorizontalFlip()(img)
        img = transforms.CenterCrop(self.img_size)(img)
        # img = transforms.ColorJitter(brightness=0.2, contrast=0.2)(img)
        img = transforms.ToTensor()(img)
        img = transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])(img)
        return img

    def test_transforms(self, img, input_size):
        img = transforms.Resize((int(1.05 * self.img_size[0]), int(1.05 * self.img_size[1])), Image.BILINEAR)(img)
        img = transforms.CenterCrop(self.img_size)(img)
        img = transforms.ToTensor()(img)
        img = transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])(img)
        return img

    def __getitem__(self, index):
        data = self.data[index]
        # Get label
        label=data[0]
        label=label.split(' ')[1]
        label=int(label)

        #Get video data
        # video_path=data[1][0].split('_')[0]
        # video_path=self.root+'/video_concate/'+video_path+'.avi'
        # video_value=self.video_transforms(video_path,n_frame=self.n_frame)

        # The second way to get video data
        video_value=self.video_list[index]

        # if self.is_train==True:
        #     video_value=augment_video(video_value)

        #Get image data
        images_path=data[2]
        image_root=self.root+'/image_pad/'
        image_values=[]
        images_path=[images_path]
        for image in images_path:
            cur_image = imageio.imread(image_root+image)
            cur_image = Image.fromarray(cur_image, mode='RGB')
            cur_image=self.train_transforms(cur_image)
            image_values.append(cur_image)
        image_values=torch.stack(image_values,dim=0)
        return index, label,video_value,image_values

    def __len__(self):
        return len(self.data)
