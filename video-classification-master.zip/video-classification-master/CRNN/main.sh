python main.py --device cuda:5 --root yourpath --batch_size 8 --n_frame 50 --epoch 100
