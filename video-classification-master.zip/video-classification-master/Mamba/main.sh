python main.py --device cuda:6 --root yourpath --batch_size 8 --n_frame 50  --epoch 100
